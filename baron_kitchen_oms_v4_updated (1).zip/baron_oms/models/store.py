"""
In-memory order store (swap for PostgreSQL in production).
Thread-safe via a lock — safe for Flask's dev server.
"""
from __future__ import annotations
import threading
from datetime import datetime, timedelta
from typing import Optional
from models.order import Order, OrderStatus


class OrderStore:
    _instance = None
    _lock = threading.Lock()

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._orders: dict[str, Order] = {}
            cls._instance._rw_lock = threading.RLock()
        return cls._instance

    # ── CRUD ──────────────────────────────────────────────────────────────
    def save(self, order: Order) -> Order:
        with self._rw_lock:
            order.updated_at = datetime.now()
            self._orders[order.order_id] = order
        return order

    def get(self, order_id: str) -> Optional[Order]:
        return self._orders.get(order_id)

    def all(self) -> list[Order]:
        with self._rw_lock:
            return sorted(self._orders.values(),
                          key=lambda o: o.created_at, reverse=True)

    def update_status(self, order_id: str, status: OrderStatus,
                      confirmed_by: str = "system") -> Optional[Order]:
        order = self.get(order_id)
        if order:
            order.status = status
            order.confirmed_by = confirmed_by
            self.save(order)
        return order

    # ── Queries ──────────────────────────────────────────────────────────
    def by_status(self, *statuses: OrderStatus) -> list[Order]:
        return [o for o in self.all() if o.status in statuses]

    def stale_drafts(self, minutes: int = 15) -> list[Order]:
        """Draft orders older than `minutes` — escalate these."""
        cutoff = datetime.now() - timedelta(minutes=minutes)
        return [
            o for o in self.all()
            if o.status == OrderStatus.DRAFT and o.created_at < cutoff
        ]

    def dispatched_unbilled(self) -> list[Order]:
        """Revenue leakage detector: dispatched but no invoice."""
        return [
            o for o in self.all()
            if o.status == OrderStatus.DISPATCHED and not o.zoho_invoice_id
        ]

    def stats(self) -> dict:
        orders = self.all()
        total_revenue = sum(o.total for o in orders
                            if o.status not in (OrderStatus.DRAFT, OrderStatus.CANCELLED))
        by_channel = {}
        by_status  = {}
        for o in orders:
            by_channel[o.channel.value] = by_channel.get(o.channel.value, 0) + 1
            by_status[o.status.value]   = by_status.get(o.status.value, 0) + 1
        return {
            "total_orders": len(orders),
            "total_revenue": round(total_revenue, 2),
            "by_channel": by_channel,
            "by_status": by_status,
            "stale_drafts": len(self.stale_drafts()),
            "unbilled_dispatched": len(self.dispatched_unbilled()),
        }
