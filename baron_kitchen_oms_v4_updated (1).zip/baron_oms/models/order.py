"""
Core data models for Baron Kitchen OMS.
All channels normalize their input into these models.
"""
from __future__ import annotations
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional


class OrderChannel(str, Enum):
    PHONE   = "phone"
    WHATSAPP = "whatsapp"
    EMAIL   = "email"
    WEBSITE = "website"


class OrderStatus(str, Enum):
    DRAFT       = "draft"        # Captured, not yet confirmed
    PENDING_REVIEW = "pending_review"  # Low AI confidence — needs human check
    CONFIRMED   = "confirmed"    # Confirmed by staff or auto
    IN_KITCHEN  = "in_kitchen"   # Sent to KDS
    DISPATCHED  = "dispatched"   # Delivery in progress
    BILLED      = "billed"       # Invoice raised in Zoho
    CANCELLED   = "cancelled"


@dataclass
class OrderItem:
    sku: str
    name: str
    qty: int
    unit_price: float

    @property
    def subtotal(self) -> float:
        return round(self.qty * self.unit_price, 2)


@dataclass
class Order:
    order_id: str = field(default_factory=lambda: str(uuid.uuid4())[:8].upper())
    channel: OrderChannel = OrderChannel.WEBSITE
    status: OrderStatus = OrderStatus.DRAFT
    client_name: str = ""
    client_contact: str = ""
    items: list[OrderItem] = field(default_factory=list)
    delivery_date: Optional[datetime] = None
    delivery_address: str = ""
    special_instructions: str = ""
    raw_input: str = ""          # Original message/transcript
    ai_confidence: float = 1.0   # 0.0–1.0 extraction confidence
    confirmed_by: str = "pending"
    zoho_invoice_id: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.now)
    updated_at: datetime = field(default_factory=datetime.now)

    @property
    def total(self) -> float:
        return round(sum(i.subtotal for i in self.items), 2)

    @property
    def is_after_hours(self) -> bool:
        h = self.created_at.hour
        return h < 8 or h >= 20

    def to_dict(self) -> dict:
        return {
            "order_id": self.order_id,
            "channel": self.channel.value,
            "status": self.status.value,
            "client_name": self.client_name,
            "client_contact": self.client_contact,
            "items": [{"sku": i.sku, "name": i.name, "qty": i.qty,
                        "unit_price": i.unit_price, "subtotal": i.subtotal}
                      for i in self.items],
            "delivery_date": self.delivery_date.isoformat() if self.delivery_date else None,
            "delivery_address": self.delivery_address,
            "special_instructions": self.special_instructions,
            "total": self.total,
            "ai_confidence": self.ai_confidence,
            "confirmed_by": self.confirmed_by,
            "zoho_invoice_id": self.zoho_invoice_id,
            "created_at": self.created_at.isoformat(),
            "status_label": self.status.value.replace("_", " ").title(),
        }
