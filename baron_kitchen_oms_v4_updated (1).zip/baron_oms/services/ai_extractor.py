"""
AI Extraction Service
---------------------
Parses unstructured text from any channel into a structured Order.
Uses OpenAI GPT-4o-mini (or Claude) via environment variable config.
Falls back to a rule-based parser if AI is unavailable.
"""
from __future__ import annotations
import json
import os
import re
from datetime import datetime, timedelta
from typing import Optional

from models.order import Order, OrderChannel, OrderItem, OrderStatus

# ── Confidence threshold ─────────────────────────────────────────────────
CONFIDENCE_THRESHOLD = 0.80   # Below this → pending_review


EXTRACTION_PROMPT = """You are an order extraction assistant for Baron Kitchen, a corporate catering company.

Extract order details from the message below and return ONLY valid JSON (no markdown, no explanation).

Return this exact structure:
{
  "client_name": "string or empty",
  "client_contact": "email or phone or empty",
  "items": [
    {"name": "string", "qty": integer, "unit_price": float}
  ],
  "delivery_date": "YYYY-MM-DD HH:MM or empty",
  "delivery_address": "string or empty",
  "special_instructions": "string or empty",
  "confidence": float between 0.0 and 1.0
}

Rules:
- confidence = 1.0 if all fields are clear; lower if ambiguous or missing key info
- If quantity not mentioned, assume 1
- If price not mentioned, use 0.0
- delivery_date: if "tomorrow" use tomorrow's date; if "today" use today
- Today is: """ + datetime.now().strftime("%Y-%m-%d") + """

Message:
"""


def _call_openai(text: str) -> Optional[dict]:
    """Call OpenAI API for extraction."""
    try:
        import openai
        client = openai.OpenAI(api_key=os.environ["OPENAI_API_KEY"])
        resp = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[{"role": "user", "content": EXTRACTION_PROMPT + text}],
            temperature=0,
            max_tokens=500,
        )
        raw = resp.choices[0].message.content.strip()
        return json.loads(raw)
    except Exception as e:
        print(f"[AI] OpenAI call failed: {e}")
        return None


def _call_anthropic(text: str) -> Optional[dict]:
    """Call Anthropic Claude API for extraction."""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
        resp = client.messages.create(
            model="claude-haiku-4-5-20251001",
            max_tokens=500,
            messages=[{"role": "user", "content": EXTRACTION_PROMPT + text}],
        )
        raw = resp.content[0].text.strip()
        return json.loads(raw)
    except Exception as e:
        print(f"[AI] Anthropic call failed: {e}")
        return None


def _rule_based_fallback(text: str) -> dict:
    """
    Simple regex fallback when no AI API is configured.
    Handles common patterns like '50 veg meals', 'for Acme Corp', etc.
    """
    items = []
    # Patterns like "50 veg meals", "10x chicken wraps", "2 boxes of salad"
    for m in re.finditer(r'(\d+)\s*x?\s+([a-zA-Z][a-zA-Z\s]{2,30}?)(?:\s+@\s*₹?([\d.]+))?(?:[,\n]|$)', text):
        qty  = int(m.group(1))
        name = m.group(2).strip().rstrip('of').strip()
        price = float(m.group(3)) if m.group(3) else 0.0
        if name:
            items.append({"name": name, "qty": qty, "unit_price": price})

    # Email / phone
    email_m = re.search(r'[\w.+-]+@[\w-]+\.\w+', text)
    phone_m = re.search(r'[\+\d][\d\s\-]{8,}', text)
    contact = email_m.group() if email_m else (phone_m.group().strip() if phone_m else "")

    # Date keywords
    delivery_date = ""
    if "tomorrow" in text.lower():
        delivery_date = (datetime.now() + timedelta(days=1)).strftime("%Y-%m-%d 12:00")
    elif "today" in text.lower():
        delivery_date = datetime.now().strftime("%Y-%m-%d 12:00")

    # Confidence: low if no items found
    confidence = 0.6 if items else 0.3

    return {
        "client_name": "",
        "client_contact": contact,
        "items": items,
        "delivery_date": delivery_date,
        "delivery_address": "",
        "special_instructions": "",
        "confidence": confidence,
    }


def _parse_date(date_str: str) -> Optional[datetime]:
    if not date_str:
        return None
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%d"):
        try:
            return datetime.strptime(date_str.strip(), fmt)
        except ValueError:
            pass
    return None


def extract_order(text: str, channel: OrderChannel) -> Order:
    """
    Main entry point: takes raw text + channel, returns an Order object.
    Tries AI APIs in order; falls back to rule-based parser.
    """
    print(f"[AI] Extracting order from {channel.value} message ({len(text)} chars)")

    parsed: Optional[dict] = None

    if os.environ.get("OPENAI_API_KEY"):
        parsed = _call_openai(text)
    elif os.environ.get("ANTHROPIC_API_KEY"):
        parsed = _call_anthropic(text)

    if not parsed:
        print("[AI] Using rule-based fallback parser")
        parsed = _rule_based_fallback(text)

    # Build OrderItems
    items = []
    for i, item_data in enumerate(parsed.get("items", [])):
        items.append(OrderItem(
            sku=f"SKU-{i+1:03d}",
            name=item_data.get("name", "Unknown item"),
            qty=max(1, int(item_data.get("qty", 1))),
            unit_price=float(item_data.get("unit_price", 0.0)),
        ))

    confidence = float(parsed.get("confidence", 0.5))
    status = (OrderStatus.PENDING_REVIEW
              if confidence < CONFIDENCE_THRESHOLD
              else OrderStatus.DRAFT)

    order = Order(
        channel=channel,
        status=status,
        client_name=parsed.get("client_name", ""),
        client_contact=parsed.get("client_contact", ""),
        items=items,
        delivery_date=_parse_date(parsed.get("delivery_date", "")),
        delivery_address=parsed.get("delivery_address", ""),
        special_instructions=parsed.get("special_instructions", ""),
        raw_input=text,
        ai_confidence=confidence,
    )

    print(f"[AI] Extracted order {order.order_id} | confidence={confidence:.0%} | status={status.value}")
    return order
