"""
Alert & Fail-safe Service
--------------------------
Runs background checks to prevent revenue leakage:
  1. Stale draft alerts (>15 min unconfirmed)
  2. Dispatched-but-unbilled detection
  3. After-hours order notifications
  4. Low-confidence review queue alerts

In production: replace _notify() with Twilio SMS / email / Slack webhook.
"""
from __future__ import annotations
import threading
import time
from datetime import datetime
from models.store import OrderStore
from models.order import OrderStatus

ALERT_LOG: list[dict] = []   # In-memory alert history (shown in dashboard)


def _notify(level: str, title: str, body: str, order_id: str = ""):
    """
    Stub notification dispatcher.
    Replace with real SMS/email/Slack calls in production.
    """
    alert = {
        "level": level,       # "warning" | "danger" | "info"
        "title": title,
        "body": body,
        "order_id": order_id,
        "timestamp": datetime.now().isoformat(),
    }
    ALERT_LOG.insert(0, alert)
    if len(ALERT_LOG) > 100:
        ALERT_LOG.pop()

    icon = {"warning": "⚠️", "danger": "🚨", "info": "ℹ️"}.get(level, "•")
    print(f"[ALERT] {icon} {title}: {body}")

    # ── Plug real integrations here ──────────────────────────────
    # twilio_sms(to=OPS_PHONE, body=f"{title}: {body}")
    # send_email(to=OPS_EMAIL, subject=title, body=body)
    # slack_webhook(channel="#ops-alerts", text=f"{icon} *{title}*\n{body}")


def check_stale_drafts():
    """Alert on orders sitting in DRAFT > 15 minutes."""
    store = OrderStore()
    stale = store.stale_drafts(minutes=15)
    for order in stale:
        age_min = int((datetime.now() - order.created_at).total_seconds() / 60)
        _notify(
            level="danger",
            title="Unconfirmed order alert",
            body=(f"Order {order.order_id} from {order.channel.value} has been in DRAFT "
                  f"for {age_min} min. Client: {order.client_name or 'Unknown'}"),
            order_id=order.order_id,
        )


def check_unbilled_dispatched():
    """Detect dispatched orders with no Zoho invoice — revenue leakage."""
    store = OrderStore()
    unbilled = store.dispatched_unbilled()
    for order in unbilled:
        _notify(
            level="danger",
            title="Revenue leakage detected",
            body=(f"Order {order.order_id} (₹{order.total}) was dispatched but "
                  f"has no invoice. Client: {order.client_name}"),
            order_id=order.order_id,
        )


def check_low_confidence_queue():
    """Remind ops about orders needing human review."""
    store = OrderStore()
    pending = store.by_status(OrderStatus.PENDING_REVIEW)
    if pending:
        _notify(
            level="warning",
            title="Review queue",
            body=f"{len(pending)} order(s) need human review (low AI confidence).",
        )


def notify_new_order(order):
    """Called immediately when a new order arrives on any channel."""
    msg = (f"New {order.channel.value} order {order.order_id} "
           f"from {order.client_name or 'Unknown'} | "
           f"₹{order.total} | conf={order.ai_confidence:.0%}")
    level = "warning" if order.ai_confidence < 0.80 else "info"
    if order.is_after_hours:
        level = "warning"
        msg += " [AFTER HOURS]"
    _notify(level=level, title="New order received", body=msg,
            order_id=order.order_id)


def notify_status_change(order, old_status: str):
    _notify(
        level="info",
        title="Order status updated",
        body=f"Order {order.order_id}: {old_status} → {order.status.value}",
        order_id=order.order_id,
    )


# ── Background watchdog thread ───────────────────────────────────────────
_watchdog_started = False

def start_watchdog(interval_seconds: int = 60):
    """Starts a background thread that runs all checks periodically."""
    global _watchdog_started
    if _watchdog_started:
        return
    _watchdog_started = True

    def loop():
        while True:
            try:
                check_stale_drafts()
                check_unbilled_dispatched()
                check_low_confidence_queue()
            except Exception as e:
                print(f"[WATCHDOG] Error: {e}")
            time.sleep(interval_seconds)

    t = threading.Thread(target=loop, daemon=True)
    t.start()
    print(f"[WATCHDOG] Started — checking every {interval_seconds}s")
