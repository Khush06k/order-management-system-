"""
Zoho Integration Service
------------------------
Handles:
  - Zoho CRM: create/update contact and deal when order is confirmed
  - Zoho Books: generate and send invoice when order is dispatched

Set these environment variables to enable live integration:
  ZOHO_CLIENT_ID, ZOHO_CLIENT_SECRET, ZOHO_REFRESH_TOKEN, ZOHO_ORG_ID

Without credentials, all calls are simulated (logged only).
"""
from __future__ import annotations
import json
import os
import time
from datetime import datetime
from typing import Optional
from models.order import Order, OrderStatus
from models.store import OrderStore

# Cached access token
_token_cache: dict = {"token": None, "expires_at": 0}


def _get_access_token() -> Optional[str]:
    """Exchange refresh token for access token (cached for 55 min)."""
    if time.time() < _token_cache["expires_at"]:
        return _token_cache["token"]

    client_id     = os.environ.get("ZOHO_CLIENT_ID")
    client_secret = os.environ.get("ZOHO_CLIENT_SECRET")
    refresh_token = os.environ.get("ZOHO_REFRESH_TOKEN")

    if not all([client_id, client_secret, refresh_token]):
        return None  # Simulation mode

    try:
        import requests
        resp = requests.post(
            "https://accounts.zoho.in/oauth/v2/token",
            params={
                "grant_type": "refresh_token",
                "client_id": client_id,
                "client_secret": client_secret,
                "refresh_token": refresh_token,
            },
            timeout=10,
        )
        data = resp.json()
        token = data.get("access_token")
        if token:
            _token_cache["token"] = token
            _token_cache["expires_at"] = time.time() + 3300  # 55 min
            return token
    except Exception as e:
        print(f"[ZOHO] Token refresh failed: {e}")
    return None


def _headers(token: str) -> dict:
    return {
        "Authorization": f"Zoho-oauthtoken {token}",
        "Content-Type": "application/json",
    }


# ── CRM ──────────────────────────────────────────────────────────────────
def sync_to_crm(order: Order) -> bool:
    """Create/update a CRM contact + deal for this order."""
    token = _get_access_token()

    if not token:
        # Simulation
        print(f"[ZOHO CRM] 🔵 SIMULATED — would sync order {order.order_id} "
              f"for client '{order.client_name}' (₹{order.total})")
        return True

    try:
        import requests
        # Upsert contact
        contact_payload = {
            "data": [{
                "Last_Name": order.client_name or "Unknown",
                "Email": order.client_contact if "@" in (order.client_contact or "") else "",
                "Phone": order.client_contact if "@" not in (order.client_contact or "") else "",
                "Lead_Source": order.channel.value.title(),
            }]
        }
        r = requests.post(
            "https://www.zohoapis.in/crm/v3/Contacts/upsert",
            headers=_headers(token),
            json=contact_payload,
            timeout=10,
        )
        print(f"[ZOHO CRM] Contact sync: {r.status_code}")

        # Create deal
        deal_payload = {
            "data": [{
                "Deal_Name": f"Order {order.order_id} — {order.client_name}",
                "Amount": order.total,
                "Stage": "Closed Won",
                "Lead_Source": order.channel.value.title(),
            }]
        }
        r2 = requests.post(
            "https://www.zohoapis.in/crm/v3/Deals",
            headers=_headers(token),
            json=deal_payload,
            timeout=10,
        )
        print(f"[ZOHO CRM] Deal created: {r2.status_code}")
        return r2.status_code in (200, 201)

    except Exception as e:
        print(f"[ZOHO CRM] Error: {e}")
        return False


# ── Books (Invoicing) ─────────────────────────────────────────────────────
def create_invoice(order: Order) -> Optional[str]:
    """
    Creates an invoice in Zoho Books and returns the invoice ID.
    Called automatically when order is dispatched.
    """
    token = _get_access_token()
    org_id = os.environ.get("ZOHO_ORG_ID", "")

    if not token:
        # Simulation — generate a fake invoice ID
        fake_id = f"INV-SIM-{order.order_id}"
        print(f"[ZOHO Books] 🔵 SIMULATED invoice {fake_id} for ₹{order.total} "
              f"— client: {order.client_name}")
        _update_order_invoice(order.order_id, fake_id)
        return fake_id

    try:
        import requests
        line_items = [
            {
                "name": item.name,
                "quantity": item.qty,
                "rate": item.unit_price,
            }
            for item in order.items
        ]
        payload = {
            "customer_name": order.client_name,
            "line_items": line_items,
            "notes": f"Order {order.order_id} via {order.channel.value}. "
                     f"{order.special_instructions}",
            "date": datetime.now().strftime("%Y-%m-%d"),
        }
        r = requests.post(
            f"https://www.zohoapis.in/books/v3/invoices?organization_id={org_id}",
            headers=_headers(token),
            json=payload,
            timeout=10,
        )
        data = r.json()
        invoice_id = data.get("invoice", {}).get("invoice_id")
        if invoice_id:
            _update_order_invoice(order.order_id, invoice_id)
            print(f"[ZOHO Books] Invoice {invoice_id} created for order {order.order_id}")
        return invoice_id

    except Exception as e:
        print(f"[ZOHO Books] Error: {e}")
        return None


def _update_order_invoice(order_id: str, invoice_id: str):
    store = OrderStore()
    order = store.get(order_id)
    if order:
        order.zoho_invoice_id = invoice_id
        order.status = OrderStatus.BILLED
        store.save(order)
