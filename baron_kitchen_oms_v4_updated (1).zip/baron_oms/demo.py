"""
Demo data seeder — populates realistic sample orders across all channels.
Call via POST /api/demo/seed or import and call seed_demo_orders() directly.
"""
from __future__ import annotations
from datetime import datetime, timedelta
from models.order import Order, OrderChannel, OrderItem, OrderStatus
from models.store import OrderStore


def seed_demo_orders():
    store = OrderStore()

    sample_orders = [
        Order(
            channel=OrderChannel.WEBSITE,
            status=OrderStatus.CONFIRMED,
            client_name="Infosys BPO",
            client_contact="admin@infosys.com",
            items=[
                OrderItem("VEG-001", "Veg Thali",         50, 180.0),
                OrderItem("NVG-001", "Chicken Biryani",   30, 220.0),
            ],
            delivery_date=datetime.now() + timedelta(days=1),
            delivery_address="Hinjewadi Phase 2, Pune",
            ai_confidence=1.0,
            confirmed_by="auto_website",
        ),
        Order(
            channel=OrderChannel.WHATSAPP,
            status=OrderStatus.DRAFT,
            client_name="TCS Pune",
            client_contact="+91 98765 43210",
            items=[
                OrderItem("VEG-002", "Paneer Box",  25, 160.0),
                OrderItem("VEG-003", "Dal Rice",    10, 120.0),
            ],
            delivery_date=datetime.now() + timedelta(hours=4),
            delivery_address="TCS Tower, Hinjewadi",
            raw_input="Hello please send 25 paneer boxes + 10 dal rice for today 1pm TCS Tower",
            ai_confidence=0.88,
            confirmed_by="pending",
        ),
        Order(
            channel=OrderChannel.EMAIL,
            status=OrderStatus.PENDING_REVIEW,
            client_name="Wipro",
            client_contact="manager@wipro.com",
            items=[
                OrderItem("MIX-001", "Mixed Veg Lunch Box", 40, 195.0),
            ],
            delivery_date=datetime.now() + timedelta(days=2),
            delivery_address="Wipro Campus, Kharadi",
            raw_input="Subject: Lunch order for 40 people\n\nHi, we need 40 mixed veg boxes for Friday.",
            ai_confidence=0.71,  # Low confidence → pending review
            confirmed_by="pending",
        ),
        Order(
            channel=OrderChannel.PHONE,
            status=OrderStatus.IN_KITCHEN,
            client_name="Cognizant",
            client_contact="+91 87654 32109",
            items=[
                OrderItem("NVG-002", "Mutton Biryani",  20, 280.0),
                OrderItem("VEG-004", "Veg Biryani",     15, 200.0),
                OrderItem("DES-001", "Gulab Jamun",     35, 40.0),
            ],
            delivery_date=datetime.now() + timedelta(hours=2),
            delivery_address="Cognizant Tower, Baner",
            raw_input="Transcript: Hi this is Priya from Cognizant, I need 20 mutton biryani and 15 veg biryani...",
            ai_confidence=0.92,
            confirmed_by="agent_001",
        ),
        Order(
            channel=OrderChannel.WEBSITE,
            status=OrderStatus.DISPATCHED,
            client_name="Accenture",
            client_contact="orders@accenture.com",
            items=[
                OrderItem("VEG-001", "Veg Thali", 100, 180.0),
                OrderItem("NVG-001", "Chicken Biryani", 50, 220.0),
            ],
            delivery_date=datetime.now() - timedelta(hours=1),
            delivery_address="Magarpatta City, Pune",
            ai_confidence=1.0,
            confirmed_by="auto_website",
            # No zoho_invoice_id → will trigger unbilled alert
        ),
        Order(
            channel=OrderChannel.WHATSAPP,
            status=OrderStatus.BILLED,
            client_name="HCL Technologies",
            client_contact="+91 76543 21098",
            items=[
                OrderItem("VEG-005", "South Indian Thali", 60, 175.0),
            ],
            delivery_date=datetime.now() - timedelta(days=1),
            delivery_address="HCL Campus, Wakad",
            ai_confidence=0.95,
            confirmed_by="agent_002",
            zoho_invoice_id="INV-SIM-DEMO01",
        ),
    ]

    # Stagger created_at for realism
    for i, order in enumerate(sample_orders):
        order.created_at = datetime.now() - timedelta(minutes=i * 7 + 2)
        store.save(order)

    print(f"[DEMO] Seeded {len(sample_orders)} sample orders")
