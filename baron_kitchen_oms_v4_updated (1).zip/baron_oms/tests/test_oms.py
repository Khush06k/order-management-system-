"""
Unit tests for Baron Kitchen OMS.
Run: python -m pytest tests/ -v
"""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from datetime import datetime, timedelta
from models.order import Order, OrderChannel, OrderItem, OrderStatus
from models.store import OrderStore
from services.ai_extractor import extract_order, _rule_based_fallback


# ── Fixtures ──────────────────────────────────────────────────────────────
@pytest.fixture(autouse=True)
def clear_store():
    """Reset the singleton store between tests."""
    store = OrderStore()
    store._orders.clear()
    yield
    store._orders.clear()


# ── Model tests ───────────────────────────────────────────────────────────
class TestOrderModel:
    def test_order_total(self):
        order = Order(items=[
            OrderItem("A", "Veg Thali", 10, 180),
            OrderItem("B", "Chicken", 5, 220),
        ])
        assert order.total == 10 * 180 + 5 * 220

    def test_order_id_generated(self):
        o1, o2 = Order(), Order()
        assert o1.order_id != o2.order_id

    def test_after_hours_detection(self):
        order = Order()
        order.created_at = datetime.now().replace(hour=22)
        assert order.is_after_hours is True
        order.created_at = datetime.now().replace(hour=10)
        assert order.is_after_hours is False

    def test_to_dict_has_required_keys(self):
        order = Order(client_name="Acme")
        d = order.to_dict()
        for key in ["order_id", "channel", "status", "total", "items", "client_name"]:
            assert key in d


# ── Store tests ───────────────────────────────────────────────────────────
class TestOrderStore:
    def test_save_and_retrieve(self):
        store = OrderStore()
        order = Order(client_name="TCS")
        store.save(order)
        assert store.get(order.order_id).client_name == "TCS"

    def test_update_status(self):
        store = OrderStore()
        order = Order()
        store.save(order)
        store.update_status(order.order_id, OrderStatus.CONFIRMED)
        assert store.get(order.order_id).status == OrderStatus.CONFIRMED

    def test_stale_drafts(self):
        store = OrderStore()
        old_order = Order(status=OrderStatus.DRAFT)
        old_order.created_at = datetime.now() - timedelta(minutes=20)
        store.save(old_order)

        new_order = Order(status=OrderStatus.DRAFT)
        store.save(new_order)

        stale = store.stale_drafts(minutes=15)
        assert old_order.order_id in [o.order_id for o in stale]
        assert new_order.order_id not in [o.order_id for o in stale]

    def test_dispatched_unbilled(self):
        store = OrderStore()
        order = Order(status=OrderStatus.DISPATCHED, zoho_invoice_id=None)
        store.save(order)
        unbilled = store.dispatched_unbilled()
        assert any(o.order_id == order.order_id for o in unbilled)

    def test_stats_keys(self):
        store = OrderStore()
        stats = store.stats()
        for key in ["total_orders", "total_revenue", "by_channel", "by_status"]:
            assert key in stats


# ── AI Extractor tests ────────────────────────────────────────────────────
class TestAIExtractor:
    def test_rule_based_extracts_items(self):
        text = "Please send 30 veg meals and 10 chicken wraps for tomorrow"
        result = _rule_based_fallback(text)
        assert len(result["items"]) >= 1
        assert result["confidence"] > 0

    def test_rule_based_detects_email(self):
        text = "Hi, I'm raj@tcs.com and need 50 boxes"
        result = _rule_based_fallback(text)
        assert "raj@tcs.com" in result["client_contact"]

    def test_rule_based_detects_tomorrow(self):
        result = _rule_based_fallback("Need 10 meals tomorrow lunch")
        assert result["delivery_date"] != ""

    def test_extract_order_returns_order_object(self):
        text = "I need 20 veg thalis for Monday delivery"
        order = extract_order(text, OrderChannel.EMAIL)
        assert isinstance(order, Order)
        assert order.channel == OrderChannel.EMAIL
        assert 0.0 <= order.ai_confidence <= 1.0

    def test_low_confidence_sets_pending_review(self):
        # Empty text → low confidence → pending_review
        order = extract_order("", OrderChannel.PHONE)
        assert order.status in (OrderStatus.PENDING_REVIEW, OrderStatus.DRAFT)


# ── Channel intake tests ──────────────────────────────────────────────────
class TestChannelIntake:
    def test_phone_channel(self):
        from channels.intake import phone_channel
        order = phone_channel.intake("30 veg lunch boxes for Infosys tomorrow")
        store = OrderStore()
        assert store.get(order.order_id) is not None
        assert order.channel == OrderChannel.PHONE

    def test_website_channel_auto_confirms(self):
        from channels.intake import website_channel
        order = website_channel.intake(data={
            "client_name": "Wipro",
            "client_contact": "test@wipro.com",
            "delivery_date": "2025-12-01T12:00:00",
            "delivery_address": "Pune",
            "items": [{"sku": "V1", "name": "Veg Thali", "qty": 50, "unit_price": 180}],
        })
        assert order.status == OrderStatus.CONFIRMED
        assert order.ai_confidence == 1.0

    def test_whatsapp_sets_sender(self):
        from channels.intake import whatsapp_channel
        order = whatsapp_channel.intake(
            message="I need 10 dal rice boxes",
            sender="+91 99000 12345"
        )
        assert "+91" in order.client_contact or order.client_contact == "+91 99000 12345"


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
