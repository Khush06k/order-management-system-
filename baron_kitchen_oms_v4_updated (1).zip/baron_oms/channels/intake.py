"""
Multi-Channel Intake Handlers
------------------------------
Each channel adapter:
  1. Receives raw input in its own format
  2. Calls the AI extractor to normalize into an Order
  3. Saves to the store
  4. Fires alerts

Channels:
  - PhoneChannel    : text transcript (simulates Twilio + Whisper)
  - WhatsAppChannel : WhatsApp message text
  - EmailChannel    : email subject + body
  - WebsiteChannel  : structured JSON from the web form
"""
from __future__ import annotations
from datetime import datetime
from models.order import Order, OrderChannel, OrderItem, OrderStatus
from models.store import OrderStore
from services.ai_extractor import extract_order
from services import alerts


store = OrderStore()


# ── Base ──────────────────────────────────────────────────────────────────
class BaseChannel:
    channel: OrderChannel

    def intake(self, raw: str | dict, **kwargs) -> Order:
        raise NotImplementedError

    def _finalize(self, order: Order) -> Order:
        store.save(order)
        alerts.notify_new_order(order)
        return order


# ── Phone ─────────────────────────────────────────────────────────────────
class PhoneChannel(BaseChannel):
    """
    Receives a call transcript (from Twilio/Whisper).
    In production: webhook from Twilio → transcribe → call intake().
    """
    channel = OrderChannel.PHONE

    def intake(self, transcript: str, **kwargs) -> Order:
        order = extract_order(transcript, self.channel)
        # Phone orders always go to human review regardless of confidence
        if order.status == OrderStatus.DRAFT:
            order.confirmed_by = "pending_agent"
        return self._finalize(order)


# ── WhatsApp ──────────────────────────────────────────────────────────────
class WhatsAppChannel(BaseChannel):
    """
    Receives a WhatsApp message via WhatsApp Business API webhook.
    """
    channel = OrderChannel.WHATSAPP

    def intake(self, message: str, sender: str = "", **kwargs) -> Order:
        order = extract_order(message, self.channel)
        if sender and not order.client_contact:
            order.client_contact = sender
        return self._finalize(order)


# ── Email ─────────────────────────────────────────────────────────────────
class EmailChannel(BaseChannel):
    """
    Receives parsed email content (subject + body combined).
    Plug in Nylas/Zapier to route inbound emails here.
    """
    channel = OrderChannel.EMAIL

    def intake(self, subject: str = "", body: str = "",
               sender_email: str = "", **kwargs) -> Order:
        combined = f"Subject: {subject}\n\n{body}"
        order = extract_order(combined, self.channel)
        if sender_email and not order.client_contact:
            order.client_contact = sender_email
        return self._finalize(order)


# ── Website ───────────────────────────────────────────────────────────────
class WebsiteChannel(BaseChannel):
    """
    Receives structured JSON from the web order form.
    Higher confidence since data is already structured.
    """
    channel = OrderChannel.WEBSITE

    def intake(self, data: dict, **kwargs) -> Order:
        # Website data is already structured — build order directly
        items = []
        for i, item_data in enumerate(data.get("items", [])):
            items.append(OrderItem(
                sku=item_data.get("sku", f"SKU-{i+1:03d}"),
                name=item_data["name"],
                qty=int(item_data.get("qty", 1)),
                unit_price=float(item_data.get("unit_price", 0.0)),
            ))

        delivery_date = None
        if data.get("delivery_date"):
            try:
                delivery_date = datetime.fromisoformat(data["delivery_date"])
            except ValueError:
                pass

        order = Order(
            channel=self.channel,
            status=OrderStatus.CONFIRMED,   # Website orders auto-confirm
            client_name=data.get("client_name", ""),
            client_contact=data.get("client_contact", ""),
            items=items,
            delivery_date=delivery_date,
            delivery_address=data.get("delivery_address", ""),
            special_instructions=data.get("special_instructions", ""),
            raw_input=str(data),
            ai_confidence=1.0,
            confirmed_by="auto_website",
        )
        return self._finalize(order)


# ── Singleton channel instances ──────────────────────────────────────────
phone_channel    = PhoneChannel()
whatsapp_channel = WhatsAppChannel()
email_channel    = EmailChannel()
website_channel  = WebsiteChannel()
